﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace directorDeFirmeDTPT
{
    public class directoruldefirme
    {
        public List<firma> listaFirmelor = new List<firma>();
        public List<string> denumireDomeniu = new List<string>();
        public List<string> denumireSubdomeniu = new List<string>();
        public List<string> denumirCategorie = new List<string>();


    }
}
