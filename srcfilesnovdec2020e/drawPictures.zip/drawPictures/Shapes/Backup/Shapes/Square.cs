using System;
using System.Collections.Generic;
using System.Text;

namespace Shapes
{
	public class Square : Shape
	{
		float size;

		public float Size
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public Square(float size)
		{
			throw new NotImplementedException();
		}

		public override void Draw(Graphics g)
		{
			throw new NotImplementedException();
		}
	}
}
