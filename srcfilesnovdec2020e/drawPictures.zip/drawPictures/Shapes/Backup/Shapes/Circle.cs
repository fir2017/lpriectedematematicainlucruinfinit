using System;
using System.Collections.Generic;
using System.Text;

namespace Shapes
{
	public class Circle : Shape
	{
		float radius;

		public float Radius
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public Circle(float radius)
		{
			throw new NotImplementedException();
		}

		public override void Draw(Graphics g)
		{
			throw new NotImplementedException();
		}
	}
}
