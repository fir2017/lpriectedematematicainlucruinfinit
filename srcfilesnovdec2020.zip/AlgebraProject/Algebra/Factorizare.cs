using System;
using System.Collections.Generic;
using System.Text;

namespace AlgebraProject.Algebra
{
	public class Factorizare
	{
		public void DiferentaPatratelor()
		{
			throw new NotImplementedException();
		}

		public void DiferentaCuburilor()
		{
			throw new NotImplementedException();
		}

		public void SumaCuburilor()
		{
			throw new NotImplementedException();
		}

		public void Diferenta4()
		{
			throw new NotImplementedException();
		}

		public void Diferenta5()
		{
			throw new NotImplementedException();
		}

		public void Suma5()
		{
			throw new NotImplementedException();
		}

		public void SumaPuteriPare()
		{
			throw new NotImplementedException();
		}

		public void DiferentaPuteriImpare()
		{
			throw new NotImplementedException();
		}

		public void SumaPuteriImpare()
		{
			throw new NotImplementedException();
		}
	}
}
