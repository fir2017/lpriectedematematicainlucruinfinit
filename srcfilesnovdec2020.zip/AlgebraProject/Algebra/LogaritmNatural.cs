using System;
using System.Collections.Generic;
using System.Text;

namespace AlgebraProject.Algebra
{
	public class LogaritmNatural
	{
		public void LogDeXInBazae()
		{
			throw new NotImplementedException();
		}

		public void LnX()
		{
			throw new NotImplementedException();
		}
	}
}
