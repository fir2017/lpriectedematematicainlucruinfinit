using System;
using System.Collections.Generic;
using System.Text;

namespace AlgebraProject.Algebra
{
	public class Interval
	{
		Numar minim;
		Numar maxim;
		TipInterval tipIntervalDreapta;
		TipInterval tipIntervalStanga;
	}
}
