using System;
using System.Collections.Generic;
using System.Text;

namespace AlgebraProject.Algebra
{
	public class Logaritm
	{
		Numar baza;
		Numar valoare;

		public Numar Definitie()
		{
			throw new NotImplementedException();
		}

		public void LogDeUnuInBazaA()
		{
			throw new NotImplementedException();
		}

		public void LogDeAInBazaA()
		{
			throw new NotImplementedException();
		}

		public void LogDeZeroInBazaA()
		{
			throw new NotImplementedException();
		}

		public void LogDeProdusInBazaA()
		{
			throw new NotImplementedException();
		}

		public void LogDeDiviziuneInBazaA()
		{
			throw new NotImplementedException();
		}

		public void LogDePutereInBazaA()
		{
			throw new NotImplementedException();
		}

		public void LogDeRadicalInBazaNInBazaA()
		{
			throw new NotImplementedException();
		}

		public void LogDeXInBazaA()
		{
			throw new NotImplementedException();
		}

		public void LogDeCInBazaA()
		{
			throw new NotImplementedException();
		}

		public void x()
		{
			throw new NotImplementedException();
		}
	}
}
