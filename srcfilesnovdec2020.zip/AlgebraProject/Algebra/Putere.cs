using System;
using System.Collections.Generic;
using System.Text;

namespace AlgebraProject.Algebra
{
	public class Putere
	{
		Real baza;
		Rational putere;

		public void Inmultire()
		{
			throw new NotImplementedException();
		}

		public void Impartire()
		{
			throw new NotImplementedException();
		}

		public void ProdusLaPutere()
		{
			throw new NotImplementedException();
		}

		public void DivizareLaPutere()
		{
			throw new NotImplementedException();
		}

		public void PutereLaPutere()
		{
			throw new NotImplementedException();
		}

		public void PutereZero()
		{
			throw new NotImplementedException();
		}

		public void PutereUnu()
		{
			throw new NotImplementedException();
		}

		public void PutereNegativa()
		{
			throw new NotImplementedException();
		}

		public void PutereFractie()
		{
			throw new NotImplementedException();
		}
	}
}
