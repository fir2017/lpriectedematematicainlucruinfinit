using System;
using System.Collections.Generic;
using System.Text;

namespace AlgebraProject.Algebra
{
	public class Comparatia
	{
		public void MaiMic()
		{
			throw new NotImplementedException();
		}

		public void MaiMare()
		{
			throw new NotImplementedException();
		}

		public void MaiMareSiMaiMare()
		{
			throw new NotImplementedException();
		}

		public void MaiMareSiMaiMic()
		{
			throw new NotImplementedException();
		}

		public void MaiMicSiMaiMic()
		{
			throw new NotImplementedException();
		}

		public void RadicalDeProdusMaiMicSauEgalFractie()
		{
			throw new NotImplementedException();
		}

		public void SumaFractieMaiMareSauEgalX()
		{
			throw new NotImplementedException();
		}

		public void RadicalMaiMAreSauEgalFractie()
		{
			throw new NotImplementedException();
		}

		public void MaiMareSauEgal()
		{
			throw new NotImplementedException();
		}

		public void MiaMicSauEgal()
		{
			throw new NotImplementedException();
		}

		public void EcuatieMaiMareSiMaiMic()
		{
			throw new NotImplementedException();
		}

		public void Modulo()
		{
			throw new NotImplementedException();
		}

		public void Functii()
		{
			throw new NotImplementedException();
		}
	}
}
