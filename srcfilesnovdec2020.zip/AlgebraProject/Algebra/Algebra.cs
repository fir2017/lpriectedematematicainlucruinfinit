using System;
using System.Collections.Generic;
using System.Text;

namespace AlgebraProject.Algebra
{
	public class Algebra
	{
		public void EPar()
		{
			throw new NotImplementedException();
		}

		public void EImpar()
		{
			throw new NotImplementedException();
		}
	}
}
