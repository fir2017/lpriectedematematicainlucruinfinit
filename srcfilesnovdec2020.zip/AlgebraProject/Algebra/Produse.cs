using System;
using System.Collections.Generic;
using System.Text;

namespace AlgebraProject.Algebra
{
	public class Produse
	{
		public void DiferentaLaPatrat()
		{
			throw new NotImplementedException();
		}

		public void SumaLaPatrat()
		{
			throw new NotImplementedException();
		}

		public void DiferentaLaCub()
		{
			throw new NotImplementedException();
		}

		public void SumaLaCub()
		{
			throw new NotImplementedException();
		}

		public void DiferentaLa4()
		{
			throw new NotImplementedException();
		}

		public void SumaLa4()
		{
			throw new NotImplementedException();
		}

		public void SumaNLaPatrat()
		{
			throw new NotImplementedException();
		}
	}
}
