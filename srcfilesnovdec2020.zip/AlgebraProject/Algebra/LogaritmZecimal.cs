using System;
using System.Collections.Generic;
using System.Text;

namespace AlgebraProject.Algebra
{
	public class LogaritmZecimal
	{
		public void LogZecimalDeX()
		{
			throw new NotImplementedException();
		}

		public void LogDeX()
		{
			throw new NotImplementedException();
		}
	}
}
