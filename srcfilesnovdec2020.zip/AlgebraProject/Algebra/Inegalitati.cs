using System;
using System.Collections.Generic;
using System.Text;

namespace AlgebraProject.Algebra
{
	public class Inegalitati
	{
		Numar minim;
		Numar maxim;
		Interval interval;
		Grafic FormaGrafica;
	}
}
