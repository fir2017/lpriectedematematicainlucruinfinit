using System;
using System.Collections.Generic;
using System.Text;

namespace AlgebraProject.Algebra
{
	public class Discriminant
	{
	}
}
