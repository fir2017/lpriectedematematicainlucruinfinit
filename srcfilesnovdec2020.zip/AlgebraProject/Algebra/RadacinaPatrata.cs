using System;
using System.Collections.Generic;
using System.Text;

namespace AlgebraProject.Algebra
{
	public class RadacinaPatrata
	{
		Numar baza;
		Rational putere;
		Numar radacina;
		Numar ordin;

		public void RadicalDeProdus()
		{
			throw new NotImplementedException();
		}

		public void ProdusDeRadicali()
		{
			throw new NotImplementedException();
		}

		public void RadicalDeDiviziune()
		{
			throw new NotImplementedException();
		}

		public void DiviziuneDeRadicali()
		{
			throw new NotImplementedException();
		}

		public void RadicalDinPutereTotulLaPutere()
		{
			throw new NotImplementedException();
		}

		public void RadicalLaPutere()
		{
			throw new NotImplementedException();
		}

		public void RadicalDinPutere()
		{
			throw new NotImplementedException();
		}

		public void RadicalDeRadical()
		{
			throw new NotImplementedException();
		}

		public void RadicalTotulLaPutere()
		{
			throw new NotImplementedException();
		}

		public void UnuPeRadical()
		{
			throw new NotImplementedException();
		}

		public void APlusRadicalTotulSubRadical()
		{
			throw new NotImplementedException();
		}

		public void UnuSupraSumaDeRadicali()
		{
			throw new NotImplementedException();
		}
	}
}
