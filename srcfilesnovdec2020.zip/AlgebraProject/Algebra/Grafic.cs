using System;
using System.Collections.Generic;
using System.Text;

namespace AlgebraProject.Algebra
{
	public class Grafic
	{
		float pozitieA;
		float pozitieB;
		float pozitieX;
		Vector directieVector;
		Linie interval;
	}
}
