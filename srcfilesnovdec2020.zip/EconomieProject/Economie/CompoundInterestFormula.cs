using System;
using System.Collections.Generic;
using System.Text;

namespace EconomieProject.Economie
{
	public class CompoundInterestFormula
	{
		Numar ValoareViitoare;
		Numar DepoziInitial;
		Numar RataAnualaADobanzii;
		Numar NumarDeAniInvestiti;
		Numar NumarDeAcumulariAnuale;
		Numar Timp;
		Numar e;
		Numar r;

		public Numar FormulaGeneralaADobanziCompuse()
		{
			throw new NotImplementedException();
		}

		public Numar FormulaSimplificataADobanziCompuse()
		{
			throw new NotImplementedException();
		}

		public Numar FormulaDobanziiCompuseContinuu()
		{
			throw new NotImplementedException();
		}
	}
}
