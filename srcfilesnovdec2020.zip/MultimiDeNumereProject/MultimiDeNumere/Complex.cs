using System;
using System.Collections.Generic;
using System.Text;

namespace MultimiDeNumereProject.MultimiDeNumere
{
	public class Complex
	{
		Real parteaRealaX;
		Imaginar parteImaginaraI;
		int PlanComplex;
		Real parteaRealaY;

		public void Conjugare()
		{
			throw new NotImplementedException();
		}

		public void ReprezentarePolara()
		{
			throw new NotImplementedException();
		}

		public void Modul()
		{
			throw new NotImplementedException();
		}

		public void Argument()
		{
			throw new NotImplementedException();
		}

		public void ProdusReprezentarePolara()
		{
			throw new NotImplementedException();
		}

		public void ConjugatReprezentarePolara()
		{
			throw new NotImplementedException();
		}

		public void InversReprezentarePolara()
		{
			throw new NotImplementedException();
		}

		public void FractieReprezentarePolara()
		{
			throw new NotImplementedException();
		}

		public void Putere()
		{
			throw new NotImplementedException();
		}

		public void DeMoivre()
		{
			throw new NotImplementedException();
		}

		public void Euler()
		{
			throw new NotImplementedException();
		}
	}
}
