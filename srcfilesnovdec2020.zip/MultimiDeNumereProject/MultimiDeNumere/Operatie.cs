using System;
using System.Collections.Generic;
using System.Text;

namespace MultimiDeNumereProject.MultimiDeNumere
{
	public class Operatie
	{
		public void Insumare()
		{
			throw new NotImplementedException();
		}

		public void Numarare()
		{
			throw new NotImplementedException();
		}

		public void Opus()
		{
			throw new NotImplementedException();
		}

		public void Adunare()
		{
			throw new NotImplementedException();
		}

		public void Impartire()
		{
			throw new NotImplementedException();
		}

		public void Scadere()
		{
			throw new NotImplementedException();
		}

		public void Inmultire()
		{
			throw new NotImplementedException();
		}

		public void Par()
		{
			throw new NotImplementedException();
		}

		public void Impar()
		{
			throw new NotImplementedException();
		}

		public void Zero()
		{
			throw new NotImplementedException();
		}
	}
}
