using System;
using System.Collections.Generic;
using System.Text;

namespace MultimiDeNumereProject.MultimiDeNumere
{
	public interface MultimeDeNumere
	{
		char simbol
		{
			get;
			set;
		}
	}
}
