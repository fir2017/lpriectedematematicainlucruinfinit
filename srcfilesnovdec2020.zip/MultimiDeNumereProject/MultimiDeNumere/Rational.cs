using System;
using System.Collections.Generic;
using System.Text;

namespace MultimiDeNumereProject.MultimiDeNumere
{
	public class Rational
	{
		Numar numitor;
		Numar numarator;

		public void Simplificare()
		{
			throw new NotImplementedException();
		}

		public void Amplificare()
		{
			throw new NotImplementedException();
		}
	}
}
