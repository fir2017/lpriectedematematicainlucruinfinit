using System;
using System.Collections.Generic;
using System.Text;

namespace MultimiDeNumereProject.MultimiDeNumere
{
	public class Real
	{
		public void AdunareElementNeutru()
		{
			throw new NotImplementedException();
		}

		public void AdunareInvers()
		{
			throw new NotImplementedException();
		}

		public void AdunareComutativititate()
		{
			throw new NotImplementedException();
		}

		public void AdunareAsociativitate()
		{
			throw new NotImplementedException();
		}

		public void Diferenta()
		{
			throw new NotImplementedException();
		}

		public void InmultireElementNeutru()
		{
			throw new NotImplementedException();
		}

		public void InmultireInvers()
		{
			throw new NotImplementedException();
		}

		public void InmultireCuZero()
		{
			throw new NotImplementedException();
		}

		public void InmultireComutativitate()
		{
			throw new NotImplementedException();
		}

		public void InmulireAsociativitate()
		{
			throw new NotImplementedException();
		}

		public void DistributibitateaAdunarii()
		{
			throw new NotImplementedException();
		}

		public void Impartire()
		{
			throw new NotImplementedException();
		}
	}
}
