using System;
using System.Collections.Generic;
using System.Text;

namespace MultimiDeNumereProject.MultimiDeNumere
{
	public class Intreg
	{
		Numar parteaIntreaga;
		Numar parteaFractionara;
		Semn semnDeDespartire;
		char semn;

		public void Negativ()
		{
			throw new NotImplementedException();
		}

		public void Pozitiv()
		{
			throw new NotImplementedException();
		}
	}
}
