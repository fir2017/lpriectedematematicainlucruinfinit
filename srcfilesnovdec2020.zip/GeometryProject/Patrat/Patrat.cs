using System;
using System.Collections.Generic;
using System.Text;

namespace GeometryProject.Patrat
{
	public class Patrat
	{
		List <Latura> Laturi;
		List <Punct> Puncte;
		int Diagonala;
		int RAzaCerculuiCircumscris;
		int RazaCerculuiInscris;
		int Perimetrul;
		int Aria;
		int Suprafata;
	}
}
