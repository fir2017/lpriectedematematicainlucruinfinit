using System;
using System.Collections.Generic;
using System.Text;

namespace GeometryProject.Patrat
{
	public class Kite
	{
	}
}
