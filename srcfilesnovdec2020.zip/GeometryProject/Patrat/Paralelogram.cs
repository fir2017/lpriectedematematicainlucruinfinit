using System;
using System.Collections.Generic;
using System.Text;

namespace GeometryProject.Patrat
{
	public class Paralelogram
	{
		int DiagonalaPrincipala;
		int DiagonalaSecundara;

		public void UnghiDintreDiagonale()
		{
			throw new NotImplementedException();
		}

		public void UnghiuriConsecutive()
		{
			throw new NotImplementedException();
		}

		public void SumaUnghiurilorBazei()
		{
			throw new NotImplementedException();
		}
	}
}
