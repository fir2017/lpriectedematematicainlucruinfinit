using System;
using System.Collections.Generic;
using System.Text;

namespace GeometryProject.Cuburi
{
	public class TrunghiDePiramidaRegulara
	{
		int ScaleFactor;
	}
}
