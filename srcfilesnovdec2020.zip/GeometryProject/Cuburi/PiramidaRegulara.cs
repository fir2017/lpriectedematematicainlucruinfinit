using System;
using System.Collections.Generic;
using System.Text;

namespace GeometryProject.Cuburi
{
	public class PiramidaRegulara
	{
		int NumarulLaturilor;
		int LaturaLaterala;
		int PantaInaltimii;
		int NumarulDeLaturiAleBazei;
		int SemiperimetrulBazei;
		int RazaSfereiInscriseInBAza;
		int AriaBazei;
		int SuprafataArieiLaterale;
		int AriaSuprafateiTotale;
	}
}
