using System;
using System.Collections.Generic;
using System.Text;

namespace GeometryProject.Cuburi
{
	public class Prisma
	{
		Muchie MuchieLaterala;
		int AriaLateralei;
		int AriaBazei;
		int SuprafataTotala;

		public void Cavalieri()
		{
			throw new NotImplementedException();
		}
	}
}
