using System;
using System.Collections.Generic;
using System.Text;

namespace GeometryProject.Sfere
{
	public class SperoidOblate
	{
	}
}
