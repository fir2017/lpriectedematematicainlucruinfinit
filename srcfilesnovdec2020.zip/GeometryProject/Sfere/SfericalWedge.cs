using System;
using System.Collections.Generic;
using System.Text;

namespace GeometryProject.Sfere
{
	public class SfericalWedge
	{
		int UnghiDiedruGrade;
		int UnghiDiedruRadiani;
		int AriaLuniiSferice;
		int AriaSuprafeteiTotale;
	}
}
