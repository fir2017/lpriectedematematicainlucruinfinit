using System;
using System.Collections.Generic;
using System.Text;

namespace GeometryProject.Sfere
{
	public class SegmentSferic
	{
		int RazaBazeiMici;
		int RazaBazeiMari;
		int Inaltime;
		int AriaSuprafeteiSferice;
		int AriaSuprafeteiPlanuluiMare;
		int AriaSuprafeteiPlanuluiMici;
	}
}
