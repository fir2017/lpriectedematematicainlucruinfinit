using System;
using System.Collections.Generic;
using System.Text;

namespace GeometryProject.Sfere
{
	public class Sfera
	{
		int Raza;
		int Diametrul;
		int AriaSuprafetei;
		int Volum;
	}
}
