using System;
using System.Collections.Generic;
using System.Text;

namespace GeometryProject.Sfere
{
	public class Emisfera
	{
		int RazaEmisferei;
		int RazaBazei;
		int Inaltime;
		int AriaFeteiPlane;
		int AriaEmisferei;
		int AriaSuprafeteiTotale;
		int Volum;
	}
}
