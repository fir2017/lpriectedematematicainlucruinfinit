using System;
using System.Collections.Generic;
using System.Text;

namespace GeometryProject.CilindruDrept
{
	public class CilindruDrept
	{
		int RazaBazei;
		int DiametrulBazei;
		int Inaltime;
		int AriaSuprafateiLaterale;
		int AriaBazei;
		int AriaSuprafateiTotale;
		int Volumul;
	}
}
