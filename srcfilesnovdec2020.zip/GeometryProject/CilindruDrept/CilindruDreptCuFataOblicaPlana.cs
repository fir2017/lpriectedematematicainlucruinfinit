using System;
using System.Collections.Generic;
using System.Text;

namespace GeometryProject.CilindruDrept
{
	public class CilindruDreptCuFataOblicaPlana
	{
		int InaltimeaLatureiMari;
		int InaltimeaLatureiMici;
		int SuprafataLatureiLaterale;
		int AriaPlanuluiFeteiFinale;
		int AriaSuprafeteiTotale;
		int Volum;
	}
}
