using System;
using System.Collections.Generic;
using System.Text;

namespace GeometryProject.Conice
{
	public class ConCircularDrept
	{
		int RazaBazei;
		int DiametrulBazei;
		int Inaltimea;
		int InaltimeaPantei;
		int AriaSuprafeteiLaterale;
		int AriaBazei;
		int AriaSuprafeteiTotale;
		int Volum;
	}
}
