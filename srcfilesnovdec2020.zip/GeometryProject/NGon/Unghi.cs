using System;
using System.Collections.Generic;
using System.Text;

namespace GeometryProject.NGon
{
	public class Unghi
	{
	}
}
