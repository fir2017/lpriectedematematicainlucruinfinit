using System;
using System.Collections.Generic;
using System.Text;

namespace GeometryProject.Triunghi
{
	public class Triunghi
	{
		float AriaS;
		Punct A;
		Punct B;
		Punct C;
		Latura LaturaA;
		Latura LaturaB;
		Ipotenuza IpotenuzaC;
		Mediana MedianaMa;
		Mediana MedianaMb;
		Mediana MedianaMc;
		Unghi UnghiAlfa;
		Unghi UnghiBeta;
		float RazaCerculuiCircumscrisR;
		float RazaCerculuiInscrisr;
		int cotalfa;
		int secalfa;
		int cosecalfa;

		public void Aria()
		{
			throw new NotImplementedException();
		}

		public float MasuraUnghiurilorAlfaBeta()
		{
			throw new NotImplementedException();
		}

		public void sinafla()
		{
			throw new NotImplementedException();
		}

		public void cosalfa()
		{
			throw new NotImplementedException();
		}

		public void tanalfa()
		{
			throw new NotImplementedException();
		}

		public void Pitagora()
		{
			throw new NotImplementedException();
		}

		public void Distanta()
		{
			throw new NotImplementedException();
		}

		public void ProiectiaPeLatura()
		{
			throw new NotImplementedException();
		}

		public void Inaltimea()
		{
			throw new NotImplementedException();
		}

		public void abEch()
		{
			throw new NotImplementedException();
		}
	}
}
