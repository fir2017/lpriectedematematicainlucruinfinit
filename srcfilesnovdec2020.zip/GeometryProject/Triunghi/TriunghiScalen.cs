using System;
using System.Collections.Generic;
using System.Text;

namespace GeometryProject.Triunghi
{
	public class TriunghiScalen
	{
		List < Latura > Laturile;
		int Midline;

		public void Semiperimetru()
		{
			throw new NotImplementedException();
		}

		public void UngiulX()
		{
			throw new NotImplementedException();
		}

		public void MedianaLatureiX()
		{
			throw new NotImplementedException();
		}

		public void BisectoareaUnghiuluiX()
		{
			throw new NotImplementedException();
		}

		public void Existenta()
		{
			throw new NotImplementedException();
		}

		public void LegeaCosinusurilor()
		{
			throw new NotImplementedException();
		}

		public void LegeaSinusurilor()
		{
			throw new NotImplementedException();
		}

		public void Diametrul()
		{
			throw new NotImplementedException();
		}

		public void Heron()
		{
			throw new NotImplementedException();
		}

		public void InaltimeLaturaX()
		{
			throw new NotImplementedException();
		}

		public Latura LaturaMijlocie()
		{
			throw new NotImplementedException();
		}
	}
}
