using System;
using System.Collections.Generic;
using System.Text;

namespace GeometryProject.Triunghi
{
	public class TriunghiIsoscel
	{
		public void UnghiulBazei()
		{
			throw new NotImplementedException();
		}

		public void UnghiulVarfului()
		{
			throw new NotImplementedException();
		}

		public void Perimetrul()
		{
			throw new NotImplementedException();
		}

		public void Aria()
		{
			throw new NotImplementedException();
		}

		public void Lungimea()
		{
			throw new NotImplementedException();
		}

		public void Suprafata()
		{
			throw new NotImplementedException();
		}

		public void InaltimeaBazei()
		{
			throw new NotImplementedException();
		}

		public void UnghiBeta()
		{
			throw new NotImplementedException();
		}

		public void LaturaL()
		{
			throw new NotImplementedException();
		}
	}
}
