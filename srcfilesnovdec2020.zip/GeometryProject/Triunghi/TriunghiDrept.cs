using System;
using System.Collections.Generic;
using System.Text;

namespace GeometryProject.Triunghi
{
	public class TriunghiDrept
	{
		List <Puncte > puncte;

		public void sin()
		{
			throw new NotImplementedException();
		}

		public void cos()
		{
			throw new NotImplementedException();
		}

		public void tan()
		{
			throw new NotImplementedException();
		}

		public void cot()
		{
			throw new NotImplementedException();
		}

		public void sec()
		{
			throw new NotImplementedException();
		}

		public void cosec()
		{
			throw new NotImplementedException();
		}

		public void Pitagora()
		{
			throw new NotImplementedException();
		}

		public void LaturaMica()
		{
			throw new NotImplementedException();
		}

		public void LaturaMare()
		{
			throw new NotImplementedException();
		}

		public void Ipotenuza()
		{
			throw new NotImplementedException();
		}

		public void Inaltimea()
		{
			throw new NotImplementedException();
		}

		public void MedianaLaturei()
		{
			throw new NotImplementedException();
		}

		public void MedianaIpotenuzei()
		{
			throw new NotImplementedException();
		}

		public void Suprafata()
		{
			throw new NotImplementedException();
		}
	}
}
