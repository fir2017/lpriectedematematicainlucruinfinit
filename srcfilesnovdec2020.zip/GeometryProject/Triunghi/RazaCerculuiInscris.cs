using System;
using System.Collections.Generic;
using System.Text;

namespace GeometryProject.Triunghi
{
	public class RazaCerculuiInscris
	{
	}
}
