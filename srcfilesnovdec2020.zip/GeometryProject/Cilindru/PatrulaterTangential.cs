using System;
using System.Collections.Generic;
using System.Text;

namespace GeometryProject.Cilindru
{
	public class PatrulaterTangential
	{
	}
}
