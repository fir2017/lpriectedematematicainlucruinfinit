using System;
using System.Collections.Generic;
using System.Text;

namespace GeometryProject.Cercuri
{
	public class SectorDeCerc
	{
		int UnghiCentralX;
		int UnghiCentralAlfa;
	}
}
