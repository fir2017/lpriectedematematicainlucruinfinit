using System;
using System.Collections.Generic;
using System.Text;

namespace GeometryProject.Cercuri
{
	public class Cerc
	{
		Diametrul Raza;
		int Coarda;
		int SegmentSecant;
		int SegmentTangent;
		int Centru;
		int UnghiCentral;
		Triunghi TriunghiInscris;
		int Perimetru;
		int Aria;
	}
}
