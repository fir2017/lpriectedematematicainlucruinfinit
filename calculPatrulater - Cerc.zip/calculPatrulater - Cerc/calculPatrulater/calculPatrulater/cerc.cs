﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace calculPatrulater
{
    public class cerc
    {
        public float raza;
        public float X;
        public float Y;
    }
}
